#!/usr/bin/env python3
"""
Script para actualizar la base de datos con los nuevos campos del modelo Mensaje
"""

from app import app, db
from sqlalchemy import text

def migrar_base_datos():
    """Agregar nuevos campos al modelo Mensaje"""
    with app.app_context():
        try:
            # Intentar agregar las nuevas columnas
            with db.engine.connect() as conn:
                # Agregar columna telefono_origen
                try:
                    conn.execute(text('ALTER TABLE mensaje ADD COLUMN telefono_origen VARCHAR(20)'))
                    print("✅ Columna 'telefono_origen' agregada")
                except Exception as e:
                    print(f"⚠️  Columna 'telefono_origen' ya existe o error: {str(e)}")
                
                # Agregar columna direccion
                try:
                    conn.execute(text("ALTER TABLE mensaje ADD COLUMN direccion VARCHAR(20) DEFAULT 'saliente'"))
                    print("✅ Columna 'direccion' agregada")
                except Exception as e:
                    print(f"⚠️  Columna 'direccion' ya existe o error: {str(e)}")
                
                # Hacer commit de los cambios
                conn.commit()
                
                # Actualizar mensajes existentes
                try:
                    conn.execute(text("UPDATE mensaje SET direccion = 'saliente' WHERE direccion IS NULL"))
                    conn.commit()
                    print("✅ Mensajes existentes actualizados")
                except Exception as e:
                    print(f"⚠️  Error al actualizar mensajes: {str(e)}")
            
            print("\n✅ Migración completada exitosamente!")
            print("\n📝 Nuevas funcionalidades disponibles:")
            print("   - Recepción de mensajes entrantes")
            print("   - Vista de conversaciones completas")
            print("   - Historial bidireccional de mensajes")
            print("\n🔧 Próximos pasos:")
            print("   1. Reinicia la aplicación: python app.py")
            print("   2. Ve a la sección de Mensajes")
            print("   3. Configura el webhook en Twilio con la URL mostrada")
            
        except Exception as e:
            print(f"\n❌ Error durante la migración: {str(e)}")
            print("   Intenta eliminar la base de datos y ejecutar init_db.py nuevamente")

if __name__ == '__main__':
    migrar_base_datos()
